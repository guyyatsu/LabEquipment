class Arguments:
  """ Automated argument handling framework for bigger projects.

      Accepts a single required argument, ArgumentDictionary, which
  is a nested dictionary structured with keys for flag options, help text,
  a classification type, and the correct action to apply.

      Example:

        ArgumentDict = {
          0: {
            "options": ["-short", "--long"],
            "help": 'A short description of what this argument does.',
            "type": type(value_to_be_collected_by_argument),
            "action": str("ArgParse action string to be taken.")
          }
        }
  """
  def __init__(self, ArgumentDict: dict):
    import argparse
    self.parser = argparse.ArgumentParser()

    for argument in ArgumentDict.keys():
      argument = ArgumentDict[argument]
      self.parser.add_argument(
                                argument['options'][0],
                                argument['options'][1],
                                help=str(argument['help']),
                                type=argument['class'],
                                action=str(argument['action']) )

    self.args = self.parser.parse_args()





class Logger:
  """ Logging setup and associated functionality. """

  def __init__( self,
                logfile="./.log",
                loglevel=logging.INFO ):
    import logging
    logging.basicConfig(filename=logfile, level=loglevel)


  def INFO(msg: str):
    return logging.info(msg)


  def DEBUG(msg: str):
    return logging.debug(msg)


  def ErrorHandling(error):
    return logging.exception("An error was caught:\n{error}\n")





class CryptographyMethods():
  """ A collection of tools specifically dealing with the security
  of certain given credentials.

  One-Way SHA-256 hashes are implemented through self.SHA256()
  Two-Way Fernet encryption is implemented through self.Encryption()
    -- Custom keys are created with self.BuildKey(), which allows
       for the use of an 'imaginary' encr
  """

  def __init__(self):
    from base64 import urlsafe_b64encode
    import hashlib as hashlib
    from cryptography.fernet import Fernet
    self = self


  def SHA256(self, secret: str):
    """ Create a SHA-256 hash of whatever value is given. """
    return hashlib.sha256(secret.encode()).hexdigest()


  def BuildKey(self, username: str, password: str):
    """ Create a two-way encryption key using the first 32
    digits of the hash of a username and password strings.

        The results are then encoded in urlsafe-base64 bytes
    and returned to thre caller. """
    basecode = self.SHA256(str(username + password))[:32]
    key = urlsafe_b64encode(basecode.encode())
    return key


  def Encryption(self, phrase: bytes, target: str):
    intelligence = Fernet(phrase)
    return intelligence.encrypt(bytes(target, 'utf-8'))
  

  def Decryption(self, phrase: bytes, target: str):
    intelligence = Fernet(phrase)
    return intelligence.decrypt(target)